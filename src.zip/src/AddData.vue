<template>
    <div>
        <input type="text" v-model="movie.name" placeholder="name"><br><br>
        <input type="date" v-model="movie.year" placeholder="Year Of Release"><br><br>
        <input type="text" v-model="movie.plot" placeholder="plot"><br><br>
        <input type="text" v-model="movie.poster" placeholder="poster"><br><br>

        <p>Actors:</p>
        <template v-for="(actor, key) in actors">
            <input type="checkbox" :value="key" v-model="movie.actors">
            <label>{{actor.name}}</label>
        </template>

        <p>Producer:</p>
        <template v-for="(prod, key) in producers">
            <input type="radio" :value="key" v-model="movie.producer">
            <label>{{prod.name}}</label>
        </template>
        <br><br>

        <button @click="aFlag = !aFlag">New actor</button>
        <button @click="pFlag = !pFlag">New producer</button>
        <br><br>

        <button @click="subsub('movie')">Submit Movie</button>
        <br><br>

        <!-- <p>{{selActors}}</p>
        <p>{{selProd}}</p> -->

        <template v-for="i in ['actor', 'producer']">
            <template v-if="$data[i[0]+'Flag']">
                <!-- <p>{{$data[i]}}</p> -->
                <input type="text" v-model="$data[i]['name']" placeholder="name"><br><br>
                <input type="radio" value="M" v-model="$data[i]['sex']">
                <label>M</label>
                <input type="radio" value="F" v-model="$data[i]['sex']">
                <label>F</label><br><br>
                <input type="date" v-model="$data[i]['dateOfBirth']" placeholder="dob"><br><br>
                <input type="text" v-model="$data[i]['bio']" placeholder="bio"><br><br>
                <template v-for="(movie, key) in movies">
                    <input type="checkbox" :value="key" v-model="$data[i]['movies']">
                    <label>{{movie.name}}</label>
                </template>
                <br><br>
                <button @click="subsub(i)">Submit {{i}}</button>
                <br><br>
            </template>
        </template>

    </div> 


</template>

<script>
import  axios from 'axios';

export default {
    data () {
        return {
            movie: {
                name: '',
                year: '',
                plot: '',
                poster: '',
                actors: [],
                producer: '',
            },
            producer: {
                name: '',
                sex: '',
                dateOfBirth: '',
                bio: '',
                movies: []
            },
            actor: {
                name: '',
                sex: '',
                dateOfBirth: '',
                bio: '',
                movies: []
            },

            aFlag: false,
            pFlag: false,

            actors: {},
            producers: {},
            movies: {},
            getArr: ['actors', 'producers', 'movies']
        }
    },
    methods: {
        subsub(typ) {
            axios.post(`http://localhost:3000/${typ}s`, this.$data[typ])
            .then( response => {
                console.log(typ, 'sent');
            })
            .catch( error => {
                console.log(error);
            });  
        }
    },
    created () {
        for (let elm of this.getArr) {
            axios.get(`http://localhost:3000/${elm}`)
                .then(response => {
                    for (let val in response.data) {
                        let dat = response.data[val]
                        let key = dat.id
                        delete dat.id
                        this[elm][key] = dat
                    }
                })
                .catch(error => {
                    console.log(error);
                })
        }
    }
}
</script>

<style>

</style>

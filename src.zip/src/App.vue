<template>
<div id="app">
    <router-link to="/list">View Movies</router-link> | <router-link to="/add">Add data</router-link> |  <router-link to="/">Home</router-link>
    <br><br>
    <router-view></router-view>
</div>
</template>

<script>
export default {
    
}
</script>

<style>
</style>

<template>
    <div>
        <p v-for="movie in retMovies">{{movie.name}}</p>
        <!-- <template v-for="movie in retMovies">
            <p>Hi</p>
            <p> {{movie.name}}</p>
            <p>{{movie.yearOfRelease}}</p>
            <p>Actors:</p>
            <template v-for="actor in movie.actors">
                <p>{{ actors[actor].name }}</p>
            </template>
            <p> Porducer : {{ producers[movie.producer].name }}</p>
            <hr>
        </template> -->
    </div>
</template>

<script>
import  axios from 'axios';

export default {
    data () {
        return {
            actors: {},
            producers: {},
            movies: {},
            getArr: ['actors', 'producers', 'movies']
        }
    },
    computed: {
        retMovies () {
            console.log('in')
            for (let elm of this.getArr) {
                axios.get(`http://localhost:3000/${elm}`)
                    .then(response => {
                        for (let val in response.data) {
                            let dat = response.data[val]
                            let key = dat.id
                            delete dat.id
                            this[elm][key] = dat
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    })
            }
            console.log(this.movies)
            console.log(this.movies[1])
            console.log(typeof(this.movies))

            console.log(JSON.stringify([this.movies]))
            for (let i in this.movies)
                console.log(i)
            return this.movies
        }
    }
}
</script>

<style>

</style>

[0: {}]
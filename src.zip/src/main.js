import Vue from 'vue'
import App from './App.vue'
import myVueRouter from 'vue-router'
import List from './List.vue'
import AddData from './AddData.vue'
import Home from './Home.vue'

Vue.use(myVueRouter);

const routes = [
  { path: '/list', component: List },
  { path: '/add', component: AddData },
  { path: '/', component: Home}
]
const router = new myVueRouter ({
  routes : routes,
  mode: 'history' // only uses '/', no '#'
})

new Vue({
    el: '#app',
    router: router,
    render: h => h(App)
  })